#!/bin/bash

run "$@"